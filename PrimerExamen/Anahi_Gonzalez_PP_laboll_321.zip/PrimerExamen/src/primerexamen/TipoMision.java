package primerexamen;


public enum TipoMision {
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO
}
