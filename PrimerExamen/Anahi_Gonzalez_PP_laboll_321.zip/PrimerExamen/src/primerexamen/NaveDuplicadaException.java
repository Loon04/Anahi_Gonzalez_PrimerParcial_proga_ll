
package primerexamen;


public class NaveDuplicadaException extends RuntimeException {
    private static final String MESSEGE = "La nave ya esta en la lista";
    
    //public void NaveDuplicadaException(String mensaje){
    //    super(mensaje);
    //}
    
}
