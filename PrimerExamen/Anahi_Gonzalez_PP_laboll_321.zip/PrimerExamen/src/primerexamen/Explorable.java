
package primerexamen;


public interface Explorable {
    void explorar();
}
